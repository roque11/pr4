# pr4
Project 4 for Digital Systems Design

Attempts to make a limited calculator using a Altera Cyclone 5 DE1-SoC FPGA. 
This calculator will also be able to display to a monitor using VGA
